<!DOCTYPE html>
<html>

<head>
    <title>Build N' Fix</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <link rel="icon" type="img/ico" href="img/logo.ico" />
</head>

<body>

    <!--- começo da nav --->
    <section class="corpo">
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #0000">
            <a class="navbar-brand h2 ml-4" href="../Index/index.php"><img src="img/logo_menu_preto.png" width=250px
                    height=90px;></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#NavbarSite">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="NavbarSite">
                <div class="container">

                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"> Home </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#"> Contratar </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="../sobre/sobre.php"> Sobre nós </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#"> Suporte </a>
                        </li>

                        <li class="nav-item">
                            <a href="" class="btn btn-outline-dark btn-sm" data-toggle="modal"
                                data-target="#modalLoginForm" style="margin-left: 1100%;">Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--- fim da nav --->

        <!--- formulario modal de login --->
        <form name="login" action="../verificar.php" method="POST">

            <div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">

                        <!---título--->
                        <div class="modal-header text-center">
                            <h4 class="modal-title w-100 font-weight-bold">Entrar no Build N' Fix</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <!---email--->
                        <div class="modal-body mx-3">
                            <div class="md-form mb-5">
                                <i class="fa fa-camera-retro"></i>
                                <td><input name="email" type="text" class="form-control validate" id="email"
                                        maxlength="200" /></td>
                                <label data-error="wrong" data-success="right" for="defaultForm-email">Email</label>
                            </div>

                            <!---senha--->
                            <div class="md-form mb-4">
                                <i class="fas fa-lock prefix grey-text"></i>
                                <td><input name="senha" type="password" class="form-control validate" id="senha"
                                        maxlength="200" /></td>
                                <label data-error="wrong" data-success="right" for="defaultForm-email">Senha</label>
                            </div>
                        </div>

                        <!--- esqueceu a senha? --->
                        <div class="modal-footer">
                            <div class="options text-center text-md-right mt-1">
                                <p>Esqueceu a senha?<a href="#" class="text-warning"> Clique aqui.</a></p>
                            </div>

                            <!---botão--->
                            <input type="submit" name="enviar" class="btn btn-outline-warning mr-3 waves-effect ml-auto"
                                value="Logar" id="enviar" /></td>
                        </div>

                    </div>
                </div>
            </div>
        </form>

        <!--- fim do formulario --->


        <!--- Banner do site e descrição --->
        <header>
            <div class="overlay"></div>
            <video autoplay loop muted playsinline>
                <source src="img/banner.mp4" type="video/mp4">
            </video>

            <div class="container h-100">
                <div class="d-flex h-100 text-center align-items-center">
                    <div class="w-100 text-light">
                        <p class="display-3"><b>Construir nunca foi tão fácil.</b></p>
                        <p class="lead mb-0"><b>Encontre profissionais qualificados perto de você.</b></p>

                        <br><br>

                        <a href="#imgprofissional" class="btn btn-outline-light" role="button" aria-pressed="true">Sou
                            um profissional</a>
                        <a href="#imgcliente" class="btn btn-outline-light" role="button" aria-pressed="true">Sou um
                            cliente</a>
                    </div>
                </div>
            </div>
        </header>
        <!--- Fim do Banner --->

        <!--- Colunas com os ícones --->
        <br><br><br><br>
        <center>
            <h1 class="display-4"> Agilize seu projeto </h1>
            <h5>
                <p>Conectamos você a profissionais qualificados. Simples assim.</p>
            </h5>
        </center>

        <br><br>

        <div class="row mb-5">
            <div class="col-sm-4">
                <center>
                    <img src="img/tools.png" class="img-fluid d-block" height="100px" width="100px">
                    <br>Você especifica o serviço que precisa.
                </center>
            </div>

            <div class="col-sm-4">
                <center>
                    <img src="img/engineer.png" class="img-fluid d-block" height="100px" width="100px">
                    <br>Nós indicamos os melhores profissionais.
                </center>
            </div>

            <div class="col-sm-4">
                <center>
                    <img src="img/chat.png" class="img-fluid d-block" height="100px" width="100px">
                    <br>Vocês combinam o valor e colocam a mão na massa.
                </center>
            </div>
        </div>
        <!--- fim das colunas com ícones --->

        <!--- div prestador de serviços --->
        <div class="row mb-5">
            <div class="col-sm-4">
                <img src="img/prestador.png" id="imgprofissional" class="d-block" height="650px" width="650px">
            </div>

            <div class="col-sm-8">
                <div id="prestador" style="margin-left: 20%; margin-top: 15%">
                    <div data-spy="scroll" data-target="#navbarVertical" data-offset="0" class="scrollspySite">
                        <p class="text-left display-4" id="profissional">Para Profissionais</p>
                        <h5>
                            <p class="text-left"> Uma forma prática e segura de encontrar clientes.</p>
                        </h5>
                    </div>
                    <br>
                    <p class="text-left">O Build N' Fix te ajuda a encontrar projetos especificos</p>
                    <p class="text-left"> no seu ramo de atuação em apenas alguns cliques.</p>
                    <br><br>

                    <a href="../cad_prof/Cadastro_Profissional.php">
                        <button type="button" class="btn btn-outline-warning mr-5">
                            Cadastre-se como profissional
                        </button>
                    </a>
                </div>
            </div>
        </div>
        <!--- fim da div prestador de serviços --->

        <!--- faixa com descrição logo abaixo da div do prestador --->
        <br><br>
        <section id="containertxt" class="text background-gray">
            <div class="container">
                <h2> A agilidade que você precisa <br> em um só lugar.</h2>

                <div class="row">
                    <div class="col-md-6">
                        <p class="lead">Assine o plano que mais se adequa a suas necessidades, encontre clientes,
                            negocie o valor e coloque as mãos na massa.</p>
                    </div>

                    <div class="col-md-6">
                        <p class="lead">Aproveite os 15 dias de teste grátis e comprove a eficiência da plataforma.</p>
                    </div>
                </div>
            </div>
        </section>
        <!--- fim da faixa com descrição --->

        <!--- div cards dos planos --->
        <br>
        <center>
            <h1>
                <p>Nossos Planos</p>
            </h1>
            <p class="lead">Para todos os profissionais, para todas as necessidades.</p>
        </center>
        <br><br>
        <!--- div do card loft --->
        <center>
            <div class="card-container">
                <div class="row">
                    <div class="card-container">
                        <div class="flip-card">
                            <div class="flip-card-inner">
                                <div class="flip-card-front">
                                    <img class="card-img-top" src="img/loft.jpg">
                                </div>

                                <div class="flip-card-back">
                                    <h1 class="card-title"><br>Plano Loft</h1>
                                    <h3 class="card-subtiltle">Básico e dinâmico</h3>
                                    <h5 class="card-text">Upload de até 10 fotos para o portifólio</h5><br>
                                    <h4 class="card-subtiltle"> R$20/Mês</h4>
                                    <button type="button" class="btn btn-outline-light">Adquira</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!--- div do card master --->
                    <div class="card-container">
                        <div class="flip-card">
                            <div class="flip-card-inner">
                                <div class="flip-card-front">
                                    <img class="card-img-top" src="img/master.jpg">
                                </div>

                                <div class="flip-card-back">
                                    <h1 class="card-title"><br>Plano Master</h1>
                                    <h3 class="card-subtiltle">Completo e inovador</h3>
                                    <h5 class="card-text">Upload de até 50 fotos para o portifólio</h5><br>
                                    <h4 class="card-subtiltle">R$30/Mês</h4>
                                    <button type="button" class="btn btn-outline-light">Adquira</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </center>
        <!--- fim das divs de cards --->

        
        <!--- div do contratante de serviços --->
        <br><br><br>
        <div class="row mb-5 ml-5">
            <div class="col-sm-4 mt-5 ml-5">
                <div data-spy="scroll" data-target="#navbarVertical" data-offset="0" class="scrollspySite">
                    <h1 class="text-right display-4" id="cliente"> Para quem quer construir. </h1>
                    <h5 class="text-right"> Um jeito rápido de encontrar os melhores profissionais.</h5>
                    <br><br><br><br>
                    <p class="text-right"> Encontre prestadores de serviço de forma prática com base nas demandas do seu
                        projeto de forma rápida e gratuita.</p>
                    <br><br><br>
                    <a href="../cad_cli/cad_cli.php"><button type="button" class="btn btn-outline-warning"
                            id="btcli">Cadastre-se como Cliente</button></a>
                </div>
            </div>
            <div class="col-sm-4 mr-5">
                <img src="img/contratante.jpg" id="imgcliente" width="500px" height="500px" style="margin-left: 250px">
            </div>
        </div>
        <!--- fim da div de contratante --->

        <!--- footer --->
        <br><br><br>
        <center>
            <div id="footer">
                <hr color="#c2c2c2">
                <h1 class="lead text-white">
                    <font size="6"> Build N' Fix </font>
                </h1>
                <h6 class="lead text-muted">Construir nunca foi tão fácil.</h6>

                <ul class="site-links list-inline">
                    <li class="list-inline-item">
                        <a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Quem somos </a>
                    </li>

                    <li class="list-inline-item">
                        <a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Contato </a>
                    </li>

                    <li class="list-inline-item">
                        <a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Suporte </a>
                    </li>
                </ul>

                <form id="formularionews" action=#>
                    <div class="form-group">
                        <input type="text" name="contato" id="contato" placeholder="Assine nossa Newsletter">
                        <button type="button" class="btn btn-outline-light" id="btnews">Inscrever</button>
                    </div>
                </form>

                <br>
                <h5 class="lead text-white-50"> Etec de Santa Isabel, Santa Isabel-SP</h5><br>
                <h5 class="lead text-white">buildnfix@gmail.com</h5><br>

                <div id="copyright">
                    <p class="lead text-muted"><br>@2019 Build 'N Fix. Todos os direitos reservados. </p>
                </div>
            </div>
        </center>
    </section>
    <!--- final do footer --->
</body>

</html>