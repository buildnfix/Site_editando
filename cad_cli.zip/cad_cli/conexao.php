<?php 
		$conexao=mysqli_connect("localhost","root","","buildnfix") or die ("Erro de Conexão".mysqli_error());
?>