<!DOCTYPE html>
<html>

<head>
    <title>Build N' Fix</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <link rel="icon" type="img/ico" href="img/logo.ico" />
</head>

<body>

    <!--- começo da nav --->
    <div class="corpo">
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #0000">
            <a class="navbar-brand h2 ml-4" href="../Index/index.php"><img src="img/logo_menu_preto.png" width=250px
                    height=90px;></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#NavbarSite">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="NavbarSite">
                <div class="container">

                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="../Index/index.php"> Home </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#"> Contratar </a>
                        </li>

                        <li class="nav-item">
                        <a class="nav-link" href="../sobre/sobre.php"> Sobre nós </a> 
                        </li>

                        <li class="nav-item">
                        <a class="nav-link" href="#"> Suporte </a>
                        </li>

                        <li class="nav-item">
                            <a href="" class="btn btn-outline-dark btn-sm" data-toggle="modal"
                                data-target="#modalLoginForm" style="margin-left: 1100%;">Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--- fim da nav --->

        <!--- formulario modal de login --->
        <form name="login" action="../verificar.php" method="POST">

            <div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">

                        <!---título--->
                        <div class="modal-header text-center">
                            <h4 class="modal-title w-100 font-weight-bold">Entrar no Build N' Fix</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <!---email--->
                        <div class="modal-body mx-3">
                            <div class="md-form mb-5">
                                <i class="fa fa-camera-retro"></i>
                                <td><input name="email" type="text" class="form-control validate" id="email"
                                        maxlength="200" /></td>
                                <label data-error="wrong" data-success="right" for="defaultForm-email">Email</label>
                            </div>

                            <!---senha--->
                            <div class="md-form mb-4">
                                <i class="fas fa-lock prefix grey-text"></i>
                                <td><input name="senha" type="password" class="form-control validate" id="senha"
                                        maxlength="200" /></td>
                                <label data-error="wrong" data-success="right" for="defaultForm-email">Senha</label>
                            </div>
                        </div>

                        <!--- esqueceu a senha? --->
                        <div class="modal-footer">
                            <div class="options text-center text-md-right mt-1">
                                <p>Esqueceu a senha?<a href="#" class="text-warning"> Clique aqui.</a></p>
                            </div>

                            <!---botão--->
                            <input type="submit" name="enviar" class="btn btn-outline-warning mr-3 waves-effect ml-auto"
                                value="Logar" id="enviar" /></td>
                        </div>

                    </div>
                </div>
            </div>
        </form>

        <!--- fim do formulario --->


        <!--- Banner do site e descrição --->
        <header>
            <div class="overlay"></div>
            <video autoplay loop muted playsinline>
                <source src="img/banner.mp4" type="video/mp4">
            </video>

            <div class="container h-100">
                <div class="d-flex h-100 text-center align-items-center">
                    <div class="w-100 text-light">
                        <p class="display-3"><b>O jeito mais prático de encontrar.</b></p>
                        <p class="lead mb-0"><b>o profissional perfeito para você.</b></p><br>
                        <a href="#imgprofissional" class="btn btn-outline-light" role="button" aria-pressed="true">Sou
                            um profissional</a>
                        <a href="#imgcliente" class="btn btn-outline-light" role="button" aria-pressed="true">Sou um
                            cliente</a>
                    </div>
                </div>
            </div>
        </header>
        <!--- Fim do Banner --->

        <!---textos explicativos e animados--->
        <font align="justify">
            <section class="anime anime-start">
                <div class="grid-text">
                    <h2>O que fazemos?</h2>
                    <p>Somos uma plataforma criada para aprimorar a busca entre prestadores de serviços da área de
                        reforma e construção e seus
                        clientes. Procurar recomendações com conhecidos já é obsoleto, um site reunindo tudo o que você
                        precisa é a melhor opção,
                        por isso o Build n' Fix está aqui, para tornar sua vida mais prática.</p>
                </div>
                <div class="grid-img">
                    <img src="img/fazemos.png" width="190" height="190">
                </div>
            </section>

            <section class="anime">
                <div class="grid-img img-right">
                    <img src="img/funciona.png" width="190" height="190">
                </div>
                <div class="grid-text">
                    <h2>Como funciona?</h2>
                    <p>Tudo começa com um simples cadastro, você se classificará como prestador ou contratante e então
                        informará seus dados. </p>
                </div>
            </section>

            <section class="anime">
                <div class="grid-text">
                    <h2>Você é um cliente?</h2>
                    <p>Então vá para a página de filtro e de acordo com o local onde precisará dos serviços busque seu
                        profissional, e se gostar
                        salve-o em seus favoritos.
                    </p>
                </div>
                <div class="grid-img">
                    <img src="img/cliente.png" width="190" height="190">
                </div>
            </section>

            <section class="anime">
                <div class="grid-img img-right">
                    <img src="img/profissional.png" width="190" height="190">
                </div>
                <div class="grid-text">
                    <h2>Você é um profissional?</h2>
                    <p>Agora é só esperar os pedidos chegarem até você, seja pelas mensagens automáticas da plataforma
                        ou no seu email.</p>
                </div>
            </section>

            <section class="anime">
                <div class="grid-text">
                    <h2>Agora é só felicidade</h2>
                    <p>Você resolveu seu problema somente com cliques e agora terá os serviços que precisar na sua obra.
                    </p>
                </div>
                <div class="grid-img">
                    <img src="img/ok.png" width="190" height="190">
                </div>
            </section>
        </font>

        <section class="anime">
            <div class="grid-img img-right">
                <img src="img/avalie.png" width="190" height="190">
            </div>
            <div class="grid-text">
                <h2>Avalie quem você contratou</h2>
                <font align="justify">
                    <p>Após a finalização do seu serviço dê estrelas ao profissional para qu assim ele tenha o feedback
                        do trabalho que forneceu.</p>
                </font>
            </div>
        </section>


        <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="js/app.js"></script>

        <!---fim dos textos explicativos e animados--->

        <!--- footer --->
        <center>
            <div id="footer">
                <hr color="#c2c2c2">
                <font color="#fff" size="6">Build N' Fix </font><br>
                <h6 class="lead text-muted">Construir nunca foi tão fácil.</h6>

                <ul class="site-links list-inline">
                    <li class="list-inline-item">
                        <a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Quem somos </a>
                    </li>

                    <li class="list-inline-item">
                        <a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Contato </a>
                    </li>

                    <li class="list-inline-item">
                        <a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Suporte </a>
                    </li>
                </ul>

                <form id="formularionews" action=#>
                    <div class="form-group">
                        <input type="text" name="contato" id="contato" placeholder="Assine nossa Newsletter">
                        <button type="button" class="btn btn-outline-light" id="btnews">Inscrever</button>
                    </div>
                </form>

                <br>
                <h5 class="lead text-white-50"> Etec de Santa Isabel, Santa Isabel-SP</h5><br>
                <h5 class="lead text-white">buildnfix@gmail.com</h5><br>

                <div id="copyright">
                    <p class="lead text-muted"><br>@2019 Build 'N Fix. Todos os direitos reservados. </p>
                </div>
            </div>
        </center>
        <!--- final do footer --->
</body>

</html>